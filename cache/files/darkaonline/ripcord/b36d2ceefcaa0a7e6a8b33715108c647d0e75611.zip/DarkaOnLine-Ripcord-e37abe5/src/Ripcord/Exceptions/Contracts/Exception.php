<?php

namespace Ripcord\Exceptions\Contracts;

/**
 * This interface is implemented by all exceptions thrown by Ripcord.
 */
interface Exception
{
}
