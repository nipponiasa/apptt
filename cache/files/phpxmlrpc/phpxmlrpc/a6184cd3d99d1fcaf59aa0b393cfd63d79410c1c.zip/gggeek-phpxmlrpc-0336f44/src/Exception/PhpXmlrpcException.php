<?php

namespace PhpXmlRpc\Exception;

class PhpXmlrpcException extends \Exception
{
}
