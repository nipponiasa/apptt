Additional maps are stored in the repository neveldo/mapael-maps

Full link: https://github.com/neveldo/mapael-maps
