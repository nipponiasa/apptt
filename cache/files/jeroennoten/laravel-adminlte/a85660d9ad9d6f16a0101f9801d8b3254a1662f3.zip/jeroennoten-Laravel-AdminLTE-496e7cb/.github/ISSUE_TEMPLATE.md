| Question                | Answer
| ----------------------- | -----------------------
| Issue or Enhancement    | Issue|Enhancement
| Laravel Version         | Used version of Laravel
| Project Version         | Used version of this project

### Current Behavior

<!-- What is the actual behavior? -->

### Expected Behavior

<!-- What is the behavior you expect? -->

### Steps to Reproduce

<!-- What are the steps to reproduce this bug? Please add code examples,
screenshots or links to GitHub repositories that reproduce the problem. -->

### Possible Solutions

<!-- If you already have ideas to solve the issue, add them here or create
a Pull Request (PR). You can remove this part, if not needed. -->
