<?php

return [

    'main_navigation'               => 'ГОЛОВНЕ МЕНЮ',
    'blog'                          => 'Блог',
    'pages'                         => 'Сторінки',
    'account_settings'              => 'НАЛАШТУВАННЯ ПРОФІЛЮ',
    'profile'                       => 'Профіль',
    'change_password'               => 'Змінити пароль',
    'multilevel'                    => 'Багаторівневе меню',
    'level_one'                     => 'Рівень 1',
    'level_two'                     => 'Рівень 2',
    'level_three'                   => 'Рівень 3',
    'labels'                        => 'Мітки',
    'important'                     => 'Важливо',
    'warning'                       => 'Увага',
    'information'                   => 'Інформація',
];
